# 图书商城 Web前台模板

## 截图

### 首页
![首页](images/首页.png)

### 购物车
![购物车](images/购物车.png)

### 我的订单
![我的订单](images/我的订单.png)

### 图书详情
![图书详情](images/图书详情.png)

### 用户登录
![用户登录](images/用户登录.png)

### 用户注册
![用户注册](images/用户注册.png)

### 友情连接
![友情连接](images/友情连接.png)

## 技术
IDE：`WebStorm`
语言：`html`,`css`,`javascript`
框架：`bootstrap`,`FlatUI`

---
大学期间为课设写的图书商城模板，不维护。添加说明，希望有需要的童鞋能够方便筛选。
